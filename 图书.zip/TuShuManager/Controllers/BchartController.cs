﻿using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.SS.Util;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TuShuManager.DBUtlity;
using TuShuManager.Models;
using TuShuManager.Pclass;

namespace TuShuManager.Controllers
{
    public class BchartController : Controller
    {
        // GET: Bchart
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Readerph()
        {
            return View();
        }
        [HttpPost]
        public string ReaderphData()
        {
            string duz = "";
            string shul = "";
            string sqlduz = "select rmnum,rmname from ReaderManger";

            DataTable dtdz = SqlHelper.ExecuteDataTable(sqlduz);
            //shiwan sw = new shiwan();
            List<ReaderManger> au = new List<ReaderManger>();
            if (dtdz.Rows.Count > 0)
            {
                for (int i = 0; i < dtdz.Rows.Count; i++)
                {
                    string rmnum = dtdz.Rows[i]["rmnum"].ToString();
                    string rmname = dtdz.Rows[i]["rmname"].ToString();
                    string sqlbfshul = "select count(*) from BoReturn where brzt=N'已归还' and brrnum =@brrnum";
                    int bfshul =(int) SqlHelper.ExecuteScalar(sqlbfshul,new SqlParameter("@brrnum", rmnum));
                    au.Add(new ReaderManger()
                    {
                        rmname = rmname,
                        rmnum = rmnum,
                        ljcs= bfshul.ToString()
                    });
                }
            }

            return JsonToConvert.ToJson(au);
            //return JsonToConvert.ToJson("小张" + "," + "小李" + "," + "小明" +"," + "李明");不可以
        }
        public string AjaxExcel()
        {
            string baseimg = Request["resultBase64"];
            Session["resultBase64"] = baseimg;
            return "1";
        }
        public void OutExcel()
        {
            string baseimg = Session["resultBase64"].ToString();
            string dirPath = Server.MapPath("~/uploads/");
            //String Path = "c:\\11234221\\";// DateTime.Now.ToString("yyy-MM-dd")
            String FileName = DateTime.Now.ToString("yyyy-MM-dd HH：mm：ss") + ".xls";
            string filePath = dirPath + FileName;
            //创建一个工作簿
            HSSFWorkbook workbook = new HSSFWorkbook();
            //创建一个sheet
            ISheet sheet1 = workbook.CreateSheet("sheet1");
            // 设置列宽,excel列宽每个像素是1/256
            sheet1.SetColumnWidth(0, 18 * 256);
            sheet1.SetColumnWidth(1, 18 * 256);
           

            //将图片文件读入一个字符串
            string[] img_array = baseimg.Split(',');
            byte[] arr = Convert.FromBase64String(img_array[1]);
            //byte[] bytes = System.IO.File.ReadAllBytes(dirPath+"1.jpg");
            int pictureIdx = workbook.AddPicture(arr, PictureType.JPEG);
            HSSFPatriarch patriarch = (HSSFPatriarch)sheet1.CreateDrawingPatriarch();
            // 插图片的位置  HSSFClientAnchor（dx1,dy1,dx2,dy2,col1,row1,col2,row2) 后面再作解释
            HSSFClientAnchor anchor = new HSSFClientAnchor(70, 10, 0, 0, 2, 2, 15, 27);
            //把图片插到相应的位置
            HSSFPicture pict = (HSSFPicture)patriarch.CreatePicture(anchor, pictureIdx);
            var excelName = "读者排行榜" + DateTime.Now.ToString("yyyyMMdd") + ".xls";
            MemoryStream memoryStream = new MemoryStream();
            workbook.Write(memoryStream);
            Session["resultBase64"] = null;
            Response.AppendHeader("Content-Disposition", "attachment;filename=" + excelName);
            Response.ContentType = "application/ms-excel";
            Response.BinaryWrite(memoryStream.ToArray());
            Response.End();
            memoryStream.Dispose();
        }
    }
}