﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TuShuManager.DBUtlity;
using TuShuManager.Models;

namespace TuShuManager.Controllers
{
    public class headleftController : Controller
    {
        // GET: headleft
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult head()
        {
            HttpCookie cookie = Request.Cookies["id"];
            HttpCookie cookie1 = Request.Cookies["username"];
            if (null == cookie || null == cookie1)
            { return View("BookManger"); }
            string pid = cookie.Value;
            string sql = "select * from AdminUser where id=@pid";
            DataTable dt = SqlHelper.ExecuteDataTable(sql, new SqlParameter("@pid", pid));
            //ViewData["t"] = id;
            //if (Session["loginUserName"] == "" || Session["loginUserName"] == null)
            //{ return RedirectToAction("index", "Login"); }
            List<AdminUser> sw = new List<AdminUser>();

            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    int uid = int.Parse(dt.Rows[i]["id"].ToString());
                    string username = dt.Rows[i]["username"].ToString();
                    string password = dt.Rows[i]["password"].ToString();
                    string qq = dt.Rows[i]["qq"].ToString();
                    string email = dt.Rows[i]["email"].ToString();
                    string idate = dt.Rows[i]["idate"].ToString();

                    sw.Add(new AdminUser()
                    {
                        id = uid,
                        idate = idate,
                        email = email,
                        username = username,
                        password = password,
                        qq = qq
                    });
                }
            }
            ViewData["AdminUser"] = sw;

            return View();
        }
        public ActionResult left(object params1, object params2)
        {
            ViewData["params1"] = params1;
            if (params2.ToString() == "1")
            {
                ViewData["class1"] = "layui-nav-itemed";
                ViewData["class2"] = "";
            }
            else {
                ViewData["class2"] = "layui-nav-itemed";
                ViewData["class1"] = "";
            }
          
            return View();
        }
    }
}