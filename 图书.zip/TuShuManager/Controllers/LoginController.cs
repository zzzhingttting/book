﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TuShuManager.DBUtlity;
using TuShuManager.Models;

namespace TuShuManager.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        public ActionResult Index()
        {
          
            if (Request.Cookies["id"]!=null&& Request.Cookies["username"]!=null) {
                HttpCookie acookieid;
                HttpCookie acookieName;
                string cookieid = Request.Cookies["id"].Name;
                acookieid = new HttpCookie(cookieid);
                acookieid.Expires = DateTime.Now.AddDays(-1);
                Response.Cookies.Add(acookieid);
                string cookieName = Request.Cookies["username"].Name;
                acookieName = new HttpCookie(cookieName);
                acookieName.Expires = DateTime.Now.AddDays(-1);
                Response.Cookies.Add(acookieName);
            } 
            return View();
        }
        [HttpPost]
        public JsonResult AdminUserCheck()
        {
            string username = Request["username"].ToString();
            string password= Request["password"].ToString(); 
            Request.Cookies.Clear();
            HttpCookie cookie = new HttpCookie("id");
            HttpCookie cookie1 = new HttpCookie("username");
            string sql = "select count(*) from AdminUser where username=@username and password=@password";
            int i = (int)SqlHelper.ExecuteScalar(sql, new SqlParameter("@password", password),
                new SqlParameter("@username", username));
            string j = "0";
            if (i == 1)
            {
                j = "1";
                string sqlid = "select *  from  AdminUser where username=@username and password=@password";
                DataTable dt = SqlHelper.ExecuteDataTable(sqlid, new SqlParameter("@password", password),
                new SqlParameter("@username", username));
                cookie.Value = dt.Rows[0]["id"].ToString();
                cookie1.Value = dt.Rows[0]["username"].ToString();
                cookie.Expires = DateTime.Now + new TimeSpan(0, 1, 0, 0);
                Response.Cookies.Add(cookie);
                cookie1.Expires = DateTime.Now + new TimeSpan(0, 1, 0, 0);
                Response.Cookies.Add(cookie1);
                //Session["userid"]=dt.Rows[0]["id"].ToString();
            }
            else
            {
                j = i.ToString();
            }
            return Json(j, JsonRequestBehavior.AllowGet);
        }


    }
}