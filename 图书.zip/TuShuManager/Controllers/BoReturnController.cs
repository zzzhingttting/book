﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TuShuManager.DBUtlity;
using TuShuManager.Models;
using TuShuManager.Pclass;

namespace TuShuManager.Controllers
{
    public class BoReturnController : Controller
    {
        // GET: BoReturn
        public ActionResult Index()
        {
            HttpCookie cookie = Request.Cookies["id"];
            HttpCookie cookie1 = Request.Cookies["username"];
            if (null == cookie || null == cookie1)
            { return RedirectToAction("index", "Login"); }

            return View();
        }
        public ActionResult Bookb()
        {
            HttpCookie cookie = Request.Cookies["id"];
            HttpCookie cookie1 = Request.Cookies["username"];
            if (null == cookie || null == cookie1)
            { return RedirectToAction("index", "Login"); }

            return View();

        }
        [HttpPost]
        public string BookbData()
        {
            int page = Convert.ToInt32(Request["page"].ToString());
            int limit = Convert.ToInt32(Request["limit"].ToString());
            var start = limit * page - limit + 1;//根据分页的页面去选择数据的开始因素
            var end = limit * page;//获得分页的最后因素
            string json = "";
            //查询逾期罚款金额
            string sqlfk = "select * from OutDate";
            DataTable dtfk = SqlHelper.ExecuteDataTable(sqlfk);
            string fknum = dtfk.Rows[0]["onum"].ToString();
            if (Request["brrname"] != "" && Request["brrname"] != null)
            {
                
                string mname = Request["brrname"].ToString();
                return Bll.BoReturn.ListPageTiaoJianJsonmname(page, limit, mname);
            }
            else if (Request["brrnum"] != "" && Request["brrnum"] != null)
            {
                string mnum = Request["brrnum"].ToString();

                return Bll.BoReturn.ListPageTiaoJianJsonmnum(page,limit,mnum) ;
            }
            else
            {

                return Bll.BoReturn.ListPageTiaoJianJson(page,limit); 
            }
        }
        public ActionResult Bookbadd()
        {
            return View();
        }
        
     [HttpPost]
        public string BookReSearchBook()
        {



            string bmmnum1 = Request["bmmnum1"].ToString();

            

         return   Bll.BookManger.BookMangerCheckbmmnum1(bmmnum1);
              

        }
        [HttpPost]
        public string BookSearchReader()
        {

           

            string rmnum1 = Request["rmnum1"].ToString();

            return Bll.BoReturn.ReaderSearch(rmnum1);
        }
        [HttpPost]
        public JsonResult BookbSave()
        {

     
            string brsj = Request["bmdj"].ToString();
            string brcbs = Request["bmcbs"].ToString();
            string brbname = Request["bmmname"].ToString();
            string brbnum = Request["bmmnum"].ToString();
            string brrname = Request["rmname"].ToString();
            string brrnum = Request["rmnum"].ToString();
            //借书
            double bmsl = double.Parse(Request["bmsl"].ToString()) - 1;
            int rday = int.Parse(Request["rday"].ToString());

            return Json(Bll.BoReturn.BookB(bmsl, rday, brsj, brcbs, brbname, brbnum, brrname, brrnum), JsonRequestBehavior.AllowGet);

        }

        public ActionResult Bookr()
        {
            return View();

        }
        [HttpPost]
        public string Bookreturn()
        {
            string brsj = Request["brsj"].ToString();
            string brcbs = Request["brcbs"].ToString();
            string brbname = Request["brbname"].ToString();
            string brbnum = Request["brbnum"].ToString();
            string brrname = Request["brrname"].ToString();
            string brrnum = Request["brrnum"].ToString();
            string bryqfj = Request["bryqfj"].ToString();
            int id = int.Parse(Request["id"].ToString());
            //检测是否逾期
            double yqfk = 0;
            if (bryqfj == null || bryqfj == "")
            {
                yqfk = 0;
            }
            else {
                yqfk = double.Parse(bryqfj);
            }            
            if (yqfk > 0)
            {
                //罚款查看是否余额足够罚款,足够就罚款不够罚款不成功
                string sqlrye = "select rmyue from ReaderManger where rmnum =@rmnum ";
                DataTable dtrye = SqlHelper.ExecuteDataTable(sqlrye, new SqlParameter("@rmnum", brrnum ));
                double rye = double.Parse(dtrye.Rows[0]["rmyue"].ToString());
                if (rye > yqfk)
                {
                    //罚款
                    double rmnum = rye - double.Parse(bryqfj);
                    string sqlfk = "update ReaderManger set rmyue=@rmyue where rmnum=@rmnum";
                    SqlHelper.ExecuteNonQuery(sqlfk, new SqlParameter("@rmnum", brrnum)
                        , new SqlParameter("@rmyue", rmnum));
                    string brzt = "已归还";
                    string brhsrq = DateTime.Now.ToShortDateString();
                    string sql = "update BoReturn set brzt=@brzt,brhsrq=@brhsrq where id=@id";
                    int i = SqlHelper.ExecuteNonQuery(sql, new SqlParameter("@id", id)
                        , new SqlParameter("@brzt", brzt), new SqlParameter("@brhsrq", brhsrq)
                        //, new SqlParameter("@xtBeizhu", xtBeizhu)
                        //, new SqlParameter("@xtDate", xtDate)
                        );
                    string j = "";
                    if (i > 0)
                    {
                        j = "1";
                    }
                    else
                    {
                        j = "2";
                    }
                    return j;

                }
                else {
                    //罚款不成功余额不足
                    return "3";
                }
            }
            else {
                string brzt = "已归还";
                string brhsrq = DateTime.Now.ToShortDateString();
                string sql = "update BoReturn set brzt=@brzt,brhsrq=@brhsrq where id=@id";
                int i = SqlHelper.ExecuteNonQuery(sql, new SqlParameter("@id", id)
                    , new SqlParameter("@brzt", brzt), new SqlParameter("@brhsrq", brhsrq)
                    //, new SqlParameter("@xtBeizhu", xtBeizhu)
                    //, new SqlParameter("@xtDate", xtDate)
                    );
                string j = "";
                if (i > 0)
                {
                    j = "1";
                }
                else
                {
                    j = "2";
                }
                return j;
            }


         
        }
        [HttpPost]
        public string BookreturnDelete( )
        {
            int id = int.Parse( Request["id"].ToString());
           
            int i = Bll.BoReturn.BoReturnDelete(id);
            string j = "";
            if (i > 0)
            {
                j = "1";
            }
            else
            {
                j = "2";
            }

            return j;
        }
        public ActionResult BookbrSearch() {

            return View();
        }
        [HttpPost]
        public string BookbrSearchData() {
            int page = Convert.ToInt32(Request["page"].ToString());
            int limit = Convert.ToInt32(Request["limit"].ToString());
            var start = limit * page - limit + 1;//根据分页的页面去选择数据的开始因素
            var end = limit * page;//获得分页的最后因素
            string json = "";
            if (Request["brbnum"] != "" && Request["brbnum"] != null)
            {

                string mname = Request["brbnum"].ToString();
                string sql = "select * from(select  ROW_NUMBER()  over(order by id asc) as fy ,* from BoReturn where brbnum=@brbnum )BoReturn where (fy between " + start + " and " + end + ")";

                DataTable dt = SqlHelper.ExecuteDataTable(sql, new SqlParameter("@brbnum", mname));
                //shiwan sw = new shiwan();
                List<BoReturn> au = new List<BoReturn>();
                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        int id = int.Parse(dt.Rows[i]["id"].ToString());
                        string brbnum = dt.Rows[i]["brbnum"].ToString();
                        string brbname = dt.Rows[i]["brbname"].ToString();
                        string brrnum = dt.Rows[i]["brrnum"].ToString();
                        string brrname = dt.Rows[i]["brrname"].ToString();
                        string brbdate = dt.Rows[i]["brbdate"].ToString();
                        string brrdate = dt.Rows[i]["brrdate"].ToString();
                        string brsj = dt.Rows[i]["brsj"].ToString();
                        string brcbs = dt.Rows[i]["brcbs"].ToString();
                        string brzt = dt.Rows[i]["brzt"].ToString();
                        string brhsrq = dt.Rows[i]["brhsrq"].ToString();
                        au.Add(new BoReturn()
                        {
                            id = id,
                            brbnum = brbnum,
                            brbname = brbname,
                            brrnum = brrnum,
                            brrname = brrname,
                            brbdate = brbdate,
                            brrdate = brrdate,
                            brsj = brsj,
                            brhsrq = brhsrq,
                            brcbs = brcbs,
                            brzt = brzt
                        });
                    }
                }
                string sqlcount = "select * from BoReturn where brbnum=@brbnum  ";
                DataTable dtcount = SqlHelper.ExecuteDataTable(sqlcount, new SqlParameter("@brbnum", mname));
                int count = (int)dtcount.Rows.Count;
                string ks = "{";
                string zhon = @"""code"":0,""msg"":"""",""count"":" + count + "";
                string data = @",""data"":" + JsonToConvert.ToJson(au) + "";
                string ke = "}";

                json = ks + zhon + data + ke;
                return json;
            }
            else if (Request["brrnum"] != "" && Request["brrnum"] != null)
            {
                string mnum = Request["brrnum"].ToString();
                string sql = "select * from(select  ROW_NUMBER()  over(order by id asc) as fy ,* from BoReturn where brrnum=@brrnum  )BoReturn where (fy between " + start + " and " + end + ")";

                DataTable dt = SqlHelper.ExecuteDataTable(sql, new SqlParameter("@brrnum", mnum));
                //shiwan sw = new shiwan();
                List<BoReturn> au = new List<BoReturn>();
                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        int id = int.Parse(dt.Rows[i]["id"].ToString());
                        string brbnum = dt.Rows[i]["brbnum"].ToString();
                        string brbname = dt.Rows[i]["brbname"].ToString();
                        string brrnum = dt.Rows[i]["brrnum"].ToString();
                        string brrname = dt.Rows[i]["brrname"].ToString();
                        string brbdate = dt.Rows[i]["brbdate"].ToString();
                        string brrdate = dt.Rows[i]["brrdate"].ToString();
                        string brsj = dt.Rows[i]["brsj"].ToString();
                        string brcbs = dt.Rows[i]["brcbs"].ToString();
                        string brzt = dt.Rows[i]["brzt"].ToString();
                        string brhsrq = dt.Rows[i]["brhsrq"].ToString();
                        au.Add(new BoReturn()
                        {
                            id = id,
                            brbnum = brbnum,
                            brbname = brbname,
                            brrnum = brrnum,
                            brrname = brrname,
                            brbdate = brbdate,
                            brrdate = brrdate,
                            brsj = brsj,
                            brhsrq = brhsrq,
                            brcbs = brcbs,
                            brzt = brzt
                        });
                    }
                }
                string sqlcount = "select * from BoReturn where brrnum=@brrnum ";
                DataTable dtcount = SqlHelper.ExecuteDataTable(sqlcount, new SqlParameter("@brrnum", mnum));
                int count = (int)dtcount.Rows.Count;
                string ks = "{";
                string zhon = @"""code"":0,""msg"":"""",""count"":" + count + "";
                string data = @",""data"":" + JsonToConvert.ToJson(au) + "";
                string ke = "}";

                json = ks + zhon + data + ke;
                return json;
            }
            else if (Request["sdate"] != "" && Request["sdate"] != null && Request["edate"] != "" && Request["edate"] != null)
            {
                string sdate = Request["sdate"].ToString();
                string edate = Request["edate"].ToString();
               
                    string sql = "select * from(select  ROW_NUMBER()  over(order by id asc) as fy ,* from BoReturn )BoReturn where (fy between " + start + " and " + end + ") and(brhsrq between '" + sdate + "' and '" + edate + "')";

                DataTable dt = SqlHelper.ExecuteDataTable(sql);
                //shiwan sw = new shiwan();
                List<BoReturn> au = new List<BoReturn>();
                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        int id = int.Parse(dt.Rows[i]["id"].ToString());
                        string brbnum = dt.Rows[i]["brbnum"].ToString();
                        string brbname = dt.Rows[i]["brbname"].ToString();
                        string brrnum = dt.Rows[i]["brrnum"].ToString();
                        string brrname = dt.Rows[i]["brrname"].ToString();
                        string brbdate = dt.Rows[i]["brbdate"].ToString();
                        string brrdate = dt.Rows[i]["brrdate"].ToString();
                        string brsj = dt.Rows[i]["brsj"].ToString();
                        string brhsrq = dt.Rows[i]["brhsrq"].ToString();
                        string brcbs = dt.Rows[i]["brcbs"].ToString();
                        string brzt = dt.Rows[i]["brzt"].ToString();

                        au.Add(new BoReturn()
                        {
                            id = id,
                            brbnum = brbnum,
                            brbname = brbname,
                            brrnum = brrnum,
                            brrname = brrname,
                            brbdate = brbdate,
                            brrdate = brrdate,
                            brsj = brsj,
                            brhsrq = brhsrq,
                            brcbs = brcbs,
                            brzt = brzt
                        });
                    }
                }
                string sqlcount = "select * from BoReturn where  brhsrq between '" + sdate + "' and '" + edate + "'";
                DataTable dtcount = SqlHelper.ExecuteDataTable(sqlcount);
                int count = (int)dtcount.Rows.Count;
                string ks = "{";
                string zhon = @"""code"":0,""msg"":"""",""count"":" + count + "";
                string data = @",""data"":" + JsonToConvert.ToJson(au) + "";
                string ke = "}";

                json = ks + zhon + data + ke;
                return json;
            }
            else
            {
                string sql = "select * from(select  ROW_NUMBER()  over(order by id asc) as fy ,* from BoReturn )BoReturn where (fy between " + start + " and " + end + ")";

                DataTable dt = SqlHelper.ExecuteDataTable(sql);
                //shiwan sw = new shiwan();
                List<BoReturn> au = new List<BoReturn>();
                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        int id = int.Parse(dt.Rows[i]["id"].ToString());
                        string brbnum = dt.Rows[i]["brbnum"].ToString();
                        string brbname = dt.Rows[i]["brbname"].ToString();
                        string brrnum = dt.Rows[i]["brrnum"].ToString();
                        string brrname = dt.Rows[i]["brrname"].ToString();
                        string brbdate = dt.Rows[i]["brbdate"].ToString();
                        string brrdate = dt.Rows[i]["brrdate"].ToString();
                        string brsj = dt.Rows[i]["brsj"].ToString();
                        string brhsrq = dt.Rows[i]["brhsrq"].ToString();
                        string brcbs = dt.Rows[i]["brcbs"].ToString();
                        string brzt = dt.Rows[i]["brzt"].ToString();

                        au.Add(new BoReturn()
                        {
                            id = id,
                            brbnum = brbnum,
                            brbname = brbname,
                            brrnum = brrnum,
                            brrname = brrname,
                            brbdate = brbdate,
                            brrdate = brrdate,
                            brsj = brsj,
                            brhsrq= brhsrq,
                            brcbs = brcbs,
                            brzt = brzt
                        });
                    }
                }
                string sqlcount = "select * from BoReturn ";
                DataTable dtcount = SqlHelper.ExecuteDataTable(sqlcount);
                int count = (int)dtcount.Rows.Count;
                string ks = "{";
                string zhon = @"""code"":0,""msg"":"""",""count"":" + count + "";
                string data = @",""data"":" + JsonToConvert.ToJson(au) + "";
                string ke = "}";

                json = ks + zhon + data + ke;
                return json;
            }
        }



    }
}