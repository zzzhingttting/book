﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TuShuManager.Models;
using TuShuManager.Pclass;

namespace TuShuManager.Controllers
{
    public class systemconfigController : Controller
    {

        // GET: systemconfig
        public ActionResult Index()
        {
            HttpCookie cookie = Request.Cookies["id"];
            HttpCookie cookie1 = Request.Cookies["username"];
            if (null == cookie || null == cookie1)
            { return RedirectToAction("index", "Login"); }


            return View();
        }
        [HttpPost]
        public string AdminUserData()
        {
            int page = Convert.ToInt32(Request["page"].ToString());
            int limit = Convert.ToInt32(Request["limit"].ToString());
            var start = limit * page - limit + 1;//根据分页的页面去选择数据的开始因素
            var end = limit * page;//获得分页的最后因素
            string json = "";
            if (Request["sname"] != "" && Request["sname"] != null)
            {
                string sname = Request["sname"].ToString();
               
                return Bll.AdminUser.ListPageTiaoJianJson1(page,limit,sname);
            }
            else if (Request["sdate"] != "" && Request["sdate"] != null && Request["edate"] != "" && Request["edate"] != null)
            {
                string sdate = Request["sdate"].ToString();
                string edate = Request["edate"].ToString();
                
                return Bll.AdminUser.ListPageTiaoJianTimeJson(page,limit,sdate,edate);
            }
            else {
               
                return Bll.AdminUser.ListPageTiaoJianJson(page,limit);
            }

          


         
        }
        public ActionResult adminuseradd()
        {

            HttpCookie cookie = Request.Cookies["id"];
            HttpCookie cookie1 = Request.Cookies["username"];
            if (null == cookie || null == cookie1)
            { return RedirectToAction("index", "Login"); }
            return View();
        }

        [HttpPost]
        public JsonResult adminuserSave()
        {
            string username = Request["username"].ToString();
            string password = Request["password"].ToString();
            string qq = Request["qq"].ToString();
            string email = Request["email"].ToString();
            string phone = Request["phone"].ToString();
            string sex = Request["sex"].ToString();
            string idate = Request["idate"].ToString();
            string i=  Bll.AdminUser.AdminUserAdd(username, password, qq, email, phone, sex, idate).ToString();
            return Json(i, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public string adminuserDelete()
        {
            int id = int.Parse(Request["id"]);
            int i = Bll.AdminUser.AdminUserDelete(id);
            string j = "";
            if (i > 0)
            {
                j = "1";
            }
            else
            {
                j = "2";
            }

            return j;
        }
        [HttpPost]
        public string adminuserAllDelete()
        {
            string id = Request["id"].ToString();
            String[] ss = id.Split(',');
            int i = 0;
            for (int idi = 0; idi < ss.Length; idi++)
            {
                i = Bll.AdminUser.AdminUserDelete(int.Parse(ss[idi])); 
            }
            string j = "";
            if (i > 0)
            {
                j = "1";
            }
            else
            {
                j = "2";
            }

            return j;
        }
        public ActionResult adminuserEdit(int id)
        {
            ViewData.Model = Bll.AdminUser.ListAdminUserId(id); ;
            return View();
        }
        [HttpPost]
        public JsonResult adminuserEditSave()
        {
            string username = Request["username"].ToString();
            string password = Request["password"].ToString();
            string qq = Request["qq"].ToString();
            string email = Request["email"].ToString();
            string phone = Request["phone"].ToString();
            string sex = Request["sex"].ToString();
            string idate = Request["idate"].ToString();
            int id = int.Parse(Request["id"]);
            int i = Bll.AdminUser.AdminUserEditAll(username, password, qq, email, phone, sex, idate,id);
            return Json(i, JsonRequestBehavior.AllowGet);
        }
        
            public ActionResult OutDate()
        {
       
            ViewData.Model = Bll.OutDate.ListOutDate();
            return View();
        }
        [HttpPost]
        public JsonResult OutDateSave()
        {
        
            string onum = Request["onum"].ToString();
           int id=int.Parse( Request["id"].ToString());
            string sql = "update OutDate set onum=@onum";
            int i = Bll.OutDate.OutDateEditAll(onum,id);
                return Json(i, JsonRequestBehavior.AllowGet);
        }
        
    }
 
   
}