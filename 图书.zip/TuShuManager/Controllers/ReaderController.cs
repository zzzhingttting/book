﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TuShuManager.DBUtlity;
using TuShuManager.Models;
using TuShuManager.Pclass;

namespace TuShuManager.Controllers
{
    public class ReaderController : Controller
    {
        // GET: Reader
        public ActionResult Index()
        {
            HttpCookie cookie = Request.Cookies["id"];
            HttpCookie cookie1 = Request.Cookies["username"];
            if (null == cookie || null == cookie1)
            { return RedirectToAction("index", "Login"); }

            return View();
        }
        public ActionResult ReaderCatgory()
        {
            HttpCookie cookie = Request.Cookies["id"];
            HttpCookie cookie1 = Request.Cookies["username"];
            if (null == cookie || null == cookie1)
            { return RedirectToAction("index", "Login"); }

            return View();
        }
        [HttpPost]
        public string ReaderCatgoryData()
        {
            int page = Convert.ToInt32(Request["page"].ToString());
            int limit = Convert.ToInt32(Request["limit"].ToString());
            var start = limit * page - limit + 1;//根据分页的页面去选择数据的开始因素
            var end = limit * page;//获得分页的最后因素

            return Bll.ReaderCatgory.ListPageTiaoJianJson(page,limit) ;
        }

        public ActionResult ReaderCatgoryAdd()
        {
            HttpCookie cookie = Request.Cookies["id"];
            HttpCookie cookie1 = Request.Cookies["username"];
            if (null == cookie || null == cookie1)
            { return RedirectToAction("index", "Login"); }

            return View();
        }
        [HttpPost]
        public JsonResult ReaderCatgorySave()
        {
        string rname = Request["rname"].ToString();
        string rnum  = Request["rnum"].ToString();
        string rday  = Request["rday"].ToString();
        string rxnum = Request["rxnum"].ToString();
            string idate = Request["idate"].ToString();
            int i = Bll.ReaderCatgory.ReaderCatgoryAdd(rname, rnum , rday , rxnum , idate);

            return Json(i, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public string ReaderCatgoryDelete()
        {
        
            int  id =int.Parse( Request["id"].ToString());
            
            int i =Bll.ReaderCatgory.ReaderCatgoryDelete(id);
            string j = "";
            if (i > 0)
            {
                j = "1";
            }
            else
            {
                j = "2";
            }

            return j;
        }
        public ActionResult ReaderCatgoryEdit(int id)
        {
           
            ViewData.Model = Bll.ReaderCatgory.ListReaderCatgoryId(id);
            return View();
        }
        [HttpPost]
        public JsonResult ReaderCatgoryEditSave()
        {
            string rname = Request["rname"].ToString();
            string rnum = Request["rnum"].ToString();
            string rday = Request["rday"].ToString();
            string rxnum = Request["rxnum"].ToString();
            string idate = Request["idate"].ToString();
            int id = int.Parse(Request["id"].ToString());
            int i = Bll.ReaderCatgory.ReaderCatgoryEditAll(rname, rnum, rday, rxnum, idate,id);
                return Json(i, JsonRequestBehavior.AllowGet);
        }
        public ActionResult ReaderManger() {
            HttpCookie cookie = Request.Cookies["id"];
            HttpCookie cookie1 = Request.Cookies["username"];
            if (null == cookie || null == cookie1)
            { return RedirectToAction("index", "Login"); }

            return View();
        }
        [HttpPost]
        public string ReaderMangerData()
        {
            int page = Convert.ToInt32(Request["page"].ToString());
            int limit = Convert.ToInt32(Request["limit"].ToString());
            var start = limit * page - limit + 1;//根据分页的页面去选择数据的开始因素
            var end = limit * page;//获得分页的最后因素
            string json = "";
            if (Request["rmname"] != "" && Request["rmname"] != null)
            {
                string mname = Request["rmname"].ToString();
               
                return Bll.ReaderManger.ListPageTiaoJianJsonmname(page,limit,mname);
            }
            else if (Request["rmnum"] != "" && Request["rmnum"] != null)
            {
                string mnum = Request["rmnum"].ToString();
                
                return Bll.ReaderManger.ListPageTiaoJianJsonmnum(page,limit,mnum);
            }
            else
            {

                return Bll.ReaderManger.ListPageTiaoJianJson(page,limit);
            }

        }

        [HttpPost]
        public string ReaderMangerDelete()
        {
            int id = int.Parse(Request["id"].ToString());
           
            int i = Bll.ReaderManger.ReaderMangerDelete(id);
            string j = "";
            if (i > 0)
            {
                j = "1";
            }
            else
            {
                j = "2";
            }

            return j;
        }
        [HttpPost]
        public string ReaderMangerAllDelete()
        {
            string id = Request["id"].ToString();
            String[] ss = id.Split(',');
            int i = 0;
            for (int idi = 0; idi < ss.Length; idi++)
            {
               
                i = Bll.ReaderManger.ReaderMangerDelete(int.Parse(ss[idi]));
            }
         
            string j = "";
            if (i > 0)
            {
                j = "1";
            }
            else
            {
                j = "2";
            }

            return j;
        }
        public ActionResult ReaderMangeradd() {
            HttpCookie cookie = Request.Cookies["id"];
            HttpCookie cookie1 = Request.Cookies["username"];
            if (null == cookie || null == cookie1)
            { return RedirectToAction("index", "Login"); }
            ViewData["ReaderCatgory"] = Bll.ReaderCatgory.ReaderCatgoryDt();
            return View();
        }
        [HttpPost]
        public JsonResult ReaderMangerSave()
        {
    string  rmnum      = Request["rmnum"].ToString();
    string  rmname     = Request["rmname"].ToString();
    string  rmljnum    = "";
    string  rmphone    = Request["rmphone"].ToString();
    string  rmsex      = Request["rmsex"].ToString();
    string  rmsr       = Request["rmsr"].ToString();
    string  rmcatgoryid= Request["rmcatgoryid"].ToString();
    string  rmyx       = Request["rmyx"].ToString();
    string  rmyue      = Request["rmyue"].ToString();
    string  rmbj       = Request["rmbj"].ToString();
    string rmyxq       = Request["rmyxq"].ToString();
    string  rmsfz      = Request["rmsfz"].ToString();
    string  rmemail    = Request["rmemail"].ToString();
    string  rmaddress  = Request["rmaddress"].ToString();
    string rmbeiz      = Request["rmbeiz"].ToString();
            string idate = Request["idate"].ToString();
            string sqlrmnum = "select count(*) from ReaderManger where rmnum=@rmnum";
            int irmnum = (int) SqlHelper.ExecuteScalar(sqlrmnum, new SqlParameter("@rmnum", rmnum));
            if (irmnum>0) {
                return Json("3", JsonRequestBehavior.AllowGet);
            }
            else {
                int i = Bll.ReaderManger.ReaderMangerAdd(rmnum, rmname, rmljnum, rmphone, rmsex, rmsr, rmcatgoryid, rmyx, rmbj, rmyue, rmyxq, rmsfz, rmemail, rmaddress, rmbeiz, idate);
                return Json(i, JsonRequestBehavior.AllowGet);
            }

           
        }

        public ActionResult ReaderManagerEdit(int id)
        {
           

            ViewData.Model = Bll.ReaderManger.ListReaderMangerId(id);
            ViewData["ReaderCatgory"] = Bll.ReaderCatgory.ReaderCatgoryDt();
            return View();
        }
        [HttpPost]
        public JsonResult ReaderMangerEditSave()
        {
            string rmnum = Request["rmnum"].ToString();
            string rmname = Request["rmname"].ToString();
            string rmljnum = Request["rmljnum"].ToString();
            string rmphone = Request["rmphone"].ToString();
            string rmsex = Request["rmsex"].ToString();
            string rmsr = Request["rmsr"].ToString();
            string rmcatgoryid = Request["rmcatgoryid"].ToString();
            string rmyx = Request["rmyx"].ToString();
            string rmyue = Request["rmyue"].ToString();
            string rmbj = Request["rmbj"].ToString();
            string rmyxq = Request["rmyxq"].ToString();
            string rmsfz = Request["rmsfz"].ToString();
            string rmemail = Request["rmemail"].ToString();
            string rmaddress = Request["rmaddress"].ToString();
            string rmbeiz = Request["rmbeiz"].ToString();
            string idate = Request["idate"].ToString();
            int  id = int.Parse(Request["id"].ToString());
            string sqlrmnum = "select count(*) from ReaderManger where rmnum=@rmnum and id=@id";
            int irmnum = (int)SqlHelper.ExecuteScalar(sqlrmnum, new SqlParameter("@rmnum", 
                rmnum)
                , new SqlParameter("@id", id));
            if (irmnum > 0)
            {
                               int i =Bll.ReaderManger.ReaderMangerEditAll(rmnum, rmname, rmljnum, rmphone, rmsex, rmsr, rmcatgoryid, rmyx, rmbj, rmyue, rmyxq, rmsfz, rmemail, rmaddress, rmbeiz, idate,id) ;
                return Json(i, JsonRequestBehavior.AllowGet);
            }
            else
            {
                //编号不一样
                string sqlr = "select count(*) from ReaderManger where rmnum=@rmnum";
                int ir = (int)SqlHelper.ExecuteScalar(sqlr, new SqlParameter("@rmnum", rmnum)
                    );
                if (ir > 0)
                {
                    return Json("3", JsonRequestBehavior.AllowGet);
                }
                else {
                    int i = Bll.ReaderManger.ReaderMangerEditAll(rmnum, rmname, rmljnum, rmphone, rmsex, rmsr, rmcatgoryid, rmyx, rmbj, rmyue, rmyxq, rmsfz, rmemail, rmaddress, rmbeiz, idate, id);
                    return Json(i, JsonRequestBehavior.AllowGet);
                }
               
            }
        }
        



    }
}