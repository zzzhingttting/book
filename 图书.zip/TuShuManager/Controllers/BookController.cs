﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TuShuManager.DBUtlity;
using TuShuManager.Models;
using TuShuManager.Pclass;

namespace TuShuManager.Controllers
{
    public class BookController : Controller
    {
        // GET: Book
        public ActionResult Index()
        {
            HttpCookie cookie = Request.Cookies["id"];
            HttpCookie cookie1 = Request.Cookies["username"];
            if (null == cookie || null == cookie1)
            { return RedirectToAction("index", "Login"); }

            return View();
        }
        public ActionResult BookCatgory()
        {
            HttpCookie cookie = Request.Cookies["id"];
            HttpCookie cookie1 = Request.Cookies["username"];
            if (null == cookie || null == cookie1)
            { return RedirectToAction("index", "Login"); }

            return View();
        }
        [HttpPost]
        public string BookCatgoryData()
        {
            int page = Convert.ToInt32(Request["page"].ToString());
            int limit = Convert.ToInt32(Request["limit"].ToString());
            var start = limit * page - limit + 1;//根据分页的页面去选择数据的开始因素
            var end = limit * page;//获得分页的最后因素
         
            return Bll.BookCatgory.ListPageTiaoJianJson(page,limit);
        }

        public ActionResult BookCatgoryAdd()
        {
            HttpCookie cookie = Request.Cookies["id"];
            HttpCookie cookie1 = Request.Cookies["username"];
            if (null == cookie || null == cookie1)
            { return RedirectToAction("index", "Login"); }

            return View();
        }
        [HttpPost]
        public JsonResult BookCatgorySave()
        {
            string bname = Request["bname"].ToString();
            string bnum = Request["bnum"].ToString();
            string bidate = Request["bidate"].ToString();
           
            int i = Bll.BookCatgory.BookCatgoryAdd(bname,bnum,"",bidate);

            return Json(i, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public string BookCatgoryDelete()
        {
            int id = int.Parse(Request["id"].ToString());
            int i = Bll.BookCatgory.BookCatgoryDelete(id);
            string j = "";
            if (i > 0)
            {
                j = "1";
            }
            else
            {
                j = "2";
            }

            return j;
        }
        public ActionResult BookCatgoryEdit(int id)
        { 
            ViewData.Model = Bll.BookCatgory.ListBookCatgoryId(id);
            return View();
        }
        [HttpPost]
        public JsonResult BookCatgoryEditSave()
        {
            string bname = Request["bname"].ToString();
            string bnum = Request["bnum"].ToString();
            string bidate = Request["bidate"].ToString();
            int id = int.Parse(Request["id"].ToString());
             int i = Bll.BookCatgory.BookCatgoryEditAll(bname,bnum,"",bidate,id);
            return Json(i, JsonRequestBehavior.AllowGet);
        }
        public ActionResult BookManger()
        {

            return View();
        }
        [HttpPost]
        public string BookMangerData()
        {
            int page = Convert.ToInt32(Request["page"].ToString());
            int limit = Convert.ToInt32(Request["limit"].ToString());
            var start = limit * page - limit + 1;//根据分页的页面去选择数据的开始因素
            var end = limit * page;//获得分页的最后因素
            string json = "";
            if (Request["bmmname"] != "" && Request["bmmname"] != null)
            {
                string mmname = Request["bmmname"].ToString();

                return Bll.BookManger.ListPageTiaoJianJsonmmname(page,limit,mmname); ;
            }
            else if (Request["bmnum"] != "" && Request["bmnum"] != null)
            {
                string mnum = Request["bmnum"].ToString();
               
                return Bll.BookManger.ListPageTiaoJianJsonbmnum(page,limit,mnum);
            }
            else
            {
             
                return Bll.BookManger.ListPageTiaoJianJson(page,limit);
            }

        }

        [HttpPost]
        public string BookMangerDelete()
        {
            int id = int.Parse(Request["id"].ToString());
          
            int i =Bll.BookManger.BookMangerDelete(id);
            string j = "";
            if (i > 0)
            {
                j = "1";
            }
            else
            {
                j = "2";
            }

            return j;
        }
        [HttpPost]
        public string BookMangerAllDelete()
        {
            string id = Request["id"].ToString();
            String[] ss = id.Split(',');
            int i = 0;
            for (int idi = 0; idi < ss.Length; idi++)
            {
                i = Bll.BookManger.BookMangerDelete(int.Parse(ss[idi]));
               
            }
            string j = "";
            if (i > 0)
            {
                j = "1";
            }
            else
            {
                j = "2";
            }

            return j;
        }
        public ActionResult BookMangeradd()
        {
            ViewData["BookCatgory"] = Bll.BookCatgory.BookCatgoryDt();
            return View();
        }
        [HttpPost]
        public JsonResult BookMangerSave()
        {
            string bmmnum = Request["bmmnum"].ToString();
            string bmmname = Request["bmmname"].ToString();
            string bmimg = Request["bmimg"].ToString();
            string bmtxm = Request["bmtxm"].ToString();
            string bmssh = Request["bmssh"].ToString();
            string bmisbn = Request["bmisbn"].ToString();
            string bmsl = Request["bmsl"].ToString();
            string bmbc = Request["bmbc"].ToString();
            string bmdj = Request["bmdj"].ToString();
            string bmzz = Request["bmzz"].ToString();
            string bmyz = Request["bmyz"].ToString();
            string bmzs = Request["bmzs"].ToString();
            string bmys = Request["bmys"].ToString();
            string bmcatgoryid = Request["bmcatgoryid"].ToString();
            string bmcbs = Request["bmcbs"].ToString();
            string bmidate = Request["bmidate"].ToString();
            string bmbeiz = Request["bmbeiz"].ToString();
            string sqlrmnum = "select count(*) from BookManger where bmmnum=@bmmnum";
            int irmnum = (int)SqlHelper.ExecuteScalar(sqlrmnum, new SqlParameter("@bmmnum", bmmnum));
            if (irmnum > 0)
            {
                return Json("3", JsonRequestBehavior.AllowGet);
            }
            else
            {
         
                int i = Bll.BookManger.BookMangerAdd(bmmnum,bmmname,bmimg,bmtxm,bmssh,bmisbn,bmsl,bmbc,bmdj,bmzz,bmyz,bmzs,bmys,bmcatgoryid,bmcbs,bmidate,bmbeiz);
                return Json(i, JsonRequestBehavior.AllowGet);
            }


        }

        public ActionResult BookMangerEdit(int id)
        {
            ViewData.Model = Bll.BookManger.ListBookMangerId(id);
            ViewData["BookCatgory"] = Bll.BookCatgory.BookCatgoryDt();
            return View();
        }
        [HttpPost]
        public JsonResult BookMangerEditSave()
        {
            int id = int.Parse(Request["id"].ToString());
            string bmmnum = Request["bmmnum"].ToString();
            string bmmname = Request["bmmname"].ToString();
            string bmimg = Request["bmimg"].ToString();
            string bmtxm = Request["bmtxm"].ToString();
            string bmssh = Request["bmssh"].ToString();
            string bmisbn = Request["bmisbn"].ToString();
            string bmsl = Request["bmsl"].ToString();
            string bmbc = Request["bmbc"].ToString();
            string bmdj = Request["bmdj"].ToString();
            string bmzz = Request["bmzz"].ToString();
            string bmyz = Request["bmyz"].ToString();
            string bmzs = Request["bmzs"].ToString();
            string bmys = Request["bmys"].ToString();
            string bmcatgoryid = Request["bmcatgoryid"].ToString();
            string bmcbs = Request["bmcbs"].ToString();
            string bmidate = Request["bmidate"].ToString();
            string bmbeiz = Request["bmbeiz"].ToString();
            string sqlrmnum = "select count(*) from BookManger where bmmnum=@bmmnum and id=@id";
            int irmnum = (int)SqlHelper.ExecuteScalar(sqlrmnum, new SqlParameter("@bmmnum", bmmnum)
                , new SqlParameter("@id", id));
            if (irmnum > 0)
            {


                int i = Bll.BookManger.BookMangerEditAll(bmmnum, bmmname, bmimg, bmtxm, bmssh, bmisbn, bmsl, bmbc, bmdj, bmzz, bmyz, bmzs, bmys, bmcatgoryid, bmcbs, bmidate, bmbeiz,id);
                return Json(i, JsonRequestBehavior.AllowGet);
            }
            else
            {
                //编号不一样
                string sqlr = "select count(*) from BookManger where bmmnum=@bmmnum";
                int ir = (int)SqlHelper.ExecuteScalar(sqlr, new SqlParameter("@bmmnum", bmmnum)
                    );
                if (ir > 0)
                {
                    return Json("3", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    int i = Bll.BookManger.BookMangerEditAll(bmmnum, bmmname, bmimg, bmtxm, bmssh, bmisbn, bmsl, bmbc, bmdj, bmzz, bmyz, bmzs, bmys, bmcatgoryid, bmcbs, bmidate, bmbeiz, id);

                    return Json(i, JsonRequestBehavior.AllowGet);
                }

            }
        }



    }
}