﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TuShuManager.Models
{
    public class BookCatgory
    {
        public int id { get; set; }
        public string bname { get; set; }

        public string bnum { get; set; }
        public string bidate { get; set; }
        
    }
}