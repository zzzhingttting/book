﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TuShuManager.Models
{
    public class OutDate
    {
        public int id { get; set; }
        public string onum { get; set; }
    }
}