﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TuShuManager.Models
{
    public class ReaderCatgory
    {
        public int id { get; set; }
        public string rname { get; set; }

        public string rnum { get; set; }

        public string rday { get; set; }
        public string rxnum { get; set; }
        public string idate { get; set; }
    }
}