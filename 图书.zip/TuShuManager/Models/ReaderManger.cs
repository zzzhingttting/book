﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TuShuManager.Models
{
    public class ReaderManger
    {
        public int id { get; set; }
        public string rmnum { get; set; }

        public string rmname { get; set; }

        public string rmphone { get; set; }
        public string rmsex { get; set; }

        public string rmsr { get; set; }

        public string rmcatgoryid { get; set; }
        public string rmljnum { get; set; }

        public string rmyx { get; set; }
        public string rmbj { get; set; }
        public string rmyue { get; set; }

        public string rmyxq { get; set; }
        public string rmsfz { get; set; }

        public string rmemail { get; set; }
        public string rmaddress { get; set; }

        public string rmbeiz { get; set; }
        public string idate { get; set; }
        public string rname { get; set; }
        public ReaderCatgory ReaderCatgory { get; set; }
        public string whcs { get; set; }
        public string ljcs { get; set; }

            
    }
}