using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace TuShuManager.Model
{
    public class ReaderCatgory{
        public int id { get; set; }
        public string rname { get; set;}
        public string rnum { get; set;}
        public string rday { get; set;}
        public string rxnum { get; set;}
        public string idate { get; set;}
    }
}