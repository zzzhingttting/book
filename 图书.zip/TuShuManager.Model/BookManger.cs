using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace TuShuManager.Model
{
    public class BookManger{
        public int id { get; set; }
        public string bmmnum { get; set;}
        public string bmmname { get; set;}
        public string bmimg { get; set;}
        public string bmtxm { get; set;}
        public string bmssh { get; set;}
        public string bmisbn { get; set;}
        public string bmsl { get; set;}
        public string bmbc { get; set;}
        public string bmdj { get; set;}
        public string bmzz { get; set;}
        public string bmyz { get; set;}
        public string bmzs { get; set;}
        public string bmys { get; set;}
        public string bmcatgoryid { get; set;}
        public string bmcbs { get; set;}
        public string bmidate { get; set;}
        public string bmbeiz { get; set;}
        public string bname { get; set; }
    }
}