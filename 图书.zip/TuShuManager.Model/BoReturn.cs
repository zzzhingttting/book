using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace TuShuManager.Model
{
    public class BoReturn{
        public int id { get; set; }
        public string brbnum { get; set;}
        public string brbname { get; set;}
        public string brrnum { get; set;}
        public string brrname { get; set;}
        public string brbdate { get; set;}
        public string brrdate { get; set;}
        public string brsj { get; set;}
        public string bryqts { get; set;}
        public string bryqfj { get; set;}
        public string brcbs { get; set;}
        public string brzt { get; set;}
        public string brhsrq { get; set;}
    }
}