using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace TuShuManager.Model
{
    public class DataBaseTable{
        public int id { get; set; }
        public string bname { get; set;}
        public string bnum { get; set;}
        public string Parent { get; set;}
        public string bidate { get; set;}
    }
}