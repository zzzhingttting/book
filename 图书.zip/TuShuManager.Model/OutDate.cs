using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace TuShuManager.Model
{
    public class OutDate{
        public int id { get; set; }
        public string onum { get; set;}
    }
}